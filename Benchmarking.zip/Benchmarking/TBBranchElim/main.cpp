//
// Created by alex on 26.06.23.
//

#include <random>
#include <vector>
#include "papi.h"
#include <iostream>
#include "../tools/utilities.h"

#define REP32(x) x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x; x;

std::vector<int> generateRandomVector(int seed) {
    std::random_device rd;
    std::mt19937 gen(seed);
    std::uniform_int_distribution<> distr(-10000, 10000);

    std::vector<int> vec;
    vec.reserve(1000000);

    for(int i = 0; i < 1000000; ++i) {
        vec.push_back(distr(gen));
    }

    return vec;
}



float foo_slow(std::vector<int>& vec, bool include_negatives) {
    int len = vec.size();
    int average = 0;
    int count = 0;
    for (int i = 0; i < len; i++)
    {
        if (include_negatives) {
            average += vec[i];
        }
        else
        {
            int e = abs(vec[i]);
            average += e;
            count++;
        }

    }

    if (include_negatives)
        return average / len;
    else
        return average / count;
}

template <bool include_negatives>
float foo_fast(std::vector<int>& vec) {
    int len = vec.size();
    int average = 0;
    int count = 0;
    for (int i = 0; i < len; i++) {
        if (include_negatives)
        {
            average += vec[i];
        }
        else
        {
            int e = abs(vec[i]);
            average += e;
            count++;
        }
    }

    if (include_negatives)
        return average / len;

    else
        return average / count;
}


int main() {
    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 1000;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);


    for (int i = 0; i < numRuns; ++i) {
        auto vec = generateRandomVector(i);
        PAPI_start(EventSet);
        float res = foo_slow(vec, false);
        PAPI_stop(EventSet, counters);
        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }

    for (int i = 0; i < numRuns; ++i) {
        auto vec = generateRandomVector(i);
        PAPI_start(EventSet);
        float res = foo_fast<false>(vec);
        PAPI_stop(EventSet, counters);
        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }


    removeOutliers(icm1);
    removeOutliers(icm2);
    removeOutliers(dcm1);
    removeOutliers(dcm2);
    removeOutliers(bmp1);
    removeOutliers(bmp2);
    removeOutliers(cycles1);
    removeOutliers(cycles2);


    std::cout << "Iterations" << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "foo_slow()" << std::endl;
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "foo_fast():\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;

/*
    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;

    writeVectorToFile(icm1, "../data/icm1.txt");
    writeVectorToFile(dcm1, "../data/dcm1.txt");
    writeVectorToFile(bmp1, "../data/bmp1.txt");
    writeVectorToFile(cycles1, "../data/cycles1.txt");
    writeVectorToFile(icm2, "../data/icm2.txt");
    writeVectorToFile(dcm2, "../data/dcm2.txt");
    writeVectorToFile(bmp2, "../data/bmp2.txt");
    writeVectorToFile(cycles2, "../data/cycles2.txt");
*/

    PAPI_shutdown();

    return 0;

}