import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set seaborn style and color palette
sns.set_style('darkgrid')  # Sets the style to darkgrid
sns.set_palette('dark')  # Set the color palette to 'dark'

# Load the data from 'icm1.txt' and 'icm2.txt'
nonTB_values = np.loadtxt('data/cycles1.txt')
TB_values = np.loadtxt('data/cycles2.txt')


# Plot the kernel density estimates with shaded area for 'icm1.txt' and 'icm2.txt'
sns.kdeplot(nonTB_values, label='non-TBE Variant', color='blue', fill=True)
sns.kdeplot(TB_values, label='TB Variant', color='violet', fill=True)

# Compute the means
nonTB_mean = np.mean(nonTB_values)
TB_mean = np.mean(TB_values)

# Add vertical lines for the means
plt.axvline(nonTB_mean, color='blue', linestyle='-', label='Mean non-TBE', linewidth=2)
plt.axvline(TB_mean, color='violet', linestyle='-', label='Mean TBE', linewidth=2)

# Add vertical line at the 5th percentile of each distribution
foo_slow_5th_percentile = np.percentile(nonTB_values, 5)
#plt.axvline(foo_slow_5th_percentile, color='blue', linestyle='--', label='5th Percentile Normalised', linewidth=1)

# Set plot labels and title
plt.xlabel('CPU Clock Cycles')
plt.ylabel('Density')
plt.title('Distribution of Non-TBE and TBE Variant (Outliers Removed)')

# Show the legend
plt.legend()

# Show the plot
plt.tight_layout()
plt.savefig('plots/tbe.svg', format="svg")