//
// Created by alex on 22.06.23.
//

#ifndef DODPATTERN_RISKANALYZERDOD_H
#define DODPATTERN_RISKANALYZERDOD_H


#include <vector>
#include "PositionDOD.h"

class RiskAnalyzerDOD {
private:
    std::vector<float> pnls;
    std::vector<float> percExps;
    std::vector<PositionDOD> coldPosData;
public:
    RiskAnalyzerDOD();
    void addPosition(float pnl, float percExp, PositionDOD coldData);

    float totalPnL();

    float totalExp();

    void updatePnL(float pnl, int id);

    void updateExp(float exp, int id);
};


#endif //DODPATTERN_RISKANALYZERDOD_H
