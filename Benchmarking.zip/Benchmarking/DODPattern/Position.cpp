//
// Created by alex on 22.06.23.
//

#include "Position.h"

Position::Position(int posID, std::string Instrument, std::string timeStamp){
    posID = id; Instrument = instrument; timeStamp = openingTS;
    errMessage1 = "Error XXXXXXXXXXXXXXXXXXXXXXX";
}

float Position::getPnL() {
    return pnl;
}

float Position::getPercExposure() {
    return percExposure;
}

int Position::getPosID() {
    return id;
}

std::string Position::getInstrument() {
    return instrument;
}

std::string Position::getOpeningTS() {
    return openingTS;
}

void Position::setPnL(float currPnl) {
    pnl = currPnl;
}

void Position::setPercExposure(float currExp) {
    percExposure = currExp;
}

