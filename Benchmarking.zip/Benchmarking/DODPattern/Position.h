//
// Created by alex on 22.06.23.
//
#include <string>
#ifndef CPPDESIGNPATTERNSHFT_POSITION_H
#define CPPDESIGNPATTERNSHFT_POSITION_H


class Position {
private:
    float pnl;
    float percExposure;
    int id;
    std::string openingTS;
    std::string instrument;
    std::string errMessage1;

public:
    Position(int posID, std::string Instrument, std::string timeStamp);
    float getPnL();
    float getPercExposure();
    int getPosID();
    std::string getInstrument();
    std::string getOpeningTS();
    void setPnL(float currPnl);
    void setPercExposure(float currExp);
};


#endif //CPPDESIGNPATTERNSHFT_POSITION_H
