import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set seaborn style and color palette
sns.set_style('darkgrid')  # Sets the style to darkgrid
sns.set_palette('dark')  # Set the color palette to 'dark'

# Load the data from 'icm1.txt' and 'icm2.txt'
oopValues = np.loadtxt('data/icm1.txt')
dodValues = np.loadtxt('data/icm2.txt')

# Compute the means
oopMean = np.mean(oopValues)
dodMean = np.mean(dodValues)

# Set the observed statistic
observed_statistic = np.abs(oopMean - dodMean)

# Perform permutation test
n_permutations = 10000
permuted_statistics = np.zeros(n_permutations)
for i in range(n_permutations):
    combined = np.concatenate([oopValues, dodValues])
    np.random.shuffle(combined)
    permutedOOP = combined[:len(oopValues)]
    permutedDOD = combined[len(oopValues):]
    permuted_statistics[i] = np.abs(np.mean(permutedOOP) - np.mean(permutedDOD))

# Compute p-value
p_value = np.mean(permuted_statistics > observed_statistic)

# Print the p-value
print(f'p-value = {p_value}')

# Calculate the 95th percentile of the permuted statistics
percentile_95 = np.percentile(permuted_statistics, 95)

# Plot the distribution of permuted statistics
plt.figure(figsize=(10, 6))
sns.kdeplot(permuted_statistics, color='darkorange', label='Permutation Distribution', fill=True)
plt.axvline(observed_statistic, color='black', linestyle='--', label=f'Observed Statistic: {observed_statistic:.2f} (pval: {p_value:.4f})')
plt.axvline(percentile_95, color='orange', linestyle='--', label=f'95th Percentile: {percentile_95:.2f}')
plt.title('Permutation Test for Difference of Means')
plt.xlabel('Difference of Means')
plt.ylabel('Density')
plt.legend()

plt.savefig('plots/dodPerm.svg', format="svg")
