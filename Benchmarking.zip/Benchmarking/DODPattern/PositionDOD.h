//
// Created by alex on 22.06.23.
//

#ifndef DODPATTERN_POSITIONDOD_H
#define DODPATTERN_POSITIONDOD_H


#include <string>

class PositionDOD {
private:
    int id;
    std::string openingTS;
    std::string instrument;
    std::string errMessage1;

public:
    PositionDOD(int id, std::string openingTs, std::string instrument);

    int getId() const;

    std::string getOpeningTs() const;

    std::string getInstrument() const;

};


#endif //DODPATTERN_POSITIONDOD_H
