//
// Created by alex on 22.06.23.
//

#include "PositionDOD.h"

PositionDOD::PositionDOD(int id, std::string openingTs, std::string instrument) :
    id(id), openingTS(openingTs), instrument(instrument) {
    errMessage1 = "Error XXXXXXXXXXXXXXXXXXXXXXX";
}

int PositionDOD::getId() const {
    return id;
}

std::string PositionDOD::getOpeningTs() const {
    return openingTS;
}

std::string PositionDOD::getInstrument() const {
    return instrument;
}
