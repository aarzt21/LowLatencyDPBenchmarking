//
// Created by alex on 22.06.23.
//

#include "RiskAnalyzerDOD.h"

RiskAnalyzerDOD::RiskAnalyzerDOD() {
    pnls = std::vector<float>();
    percExps = std::vector<float>();
    coldPosData = std::vector<PositionDOD>();
}

void RiskAnalyzerDOD::addPosition(float pnl, float percExp, PositionDOD coldData) {
    pnls.push_back(pnl);
    percExps.push_back(percExp);
    coldPosData.push_back(coldData);
}

float RiskAnalyzerDOD::totalPnL() {
    float totPnl = 0;
    for (auto p: pnls) totPnl += p;
    return totPnl;
}

float RiskAnalyzerDOD::totalExp() {
    float totExp = 0;
    for (auto p: percExps) totExp += p;
    return totExp;
}

void RiskAnalyzerDOD::updatePnL(float pnl, int id) {
    pnls[id] = pnl;
}

void RiskAnalyzerDOD::updateExp(float exp, int id) {
    percExps[id] = exp;
}
