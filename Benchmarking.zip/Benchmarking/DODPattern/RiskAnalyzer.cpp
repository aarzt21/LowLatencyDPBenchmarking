//
// Created by alex on 22.06.23.
//

#include "RiskAnalyzer.h"

RiskAnalyzer::RiskAnalyzer() {
    positions = std::vector<Position>();
}

float RiskAnalyzer::totalPnL() {
    float totPnl = 0;
    for (auto p: positions) totPnl += p.getPnL();
    return totPnl;
}

float RiskAnalyzer::totalExposure() {
    float totExp = 0;
    for (auto p: positions) totExp += p.getPercExposure();
    return totExp;
}
