//
// Created by alex on 22.06.23.
//

#ifndef DODPATTERN_RISKANALYZER_H
#define DODPATTERN_RISKANALYZER_H
#include "Position.h"
#include <vector>

class RiskAnalyzer {
private:
    std::vector<Position> positions;
public:
    RiskAnalyzer();
    void addOpenPosition(Position pos){
        positions.push_back(pos);
    }

    float totalPnL();

    float totalExposure();
};


#endif //DODPATTERN_RISKANALYZER_H
