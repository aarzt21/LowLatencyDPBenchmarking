//
// Created by alex on 22.06.23.
//

#include "papi.h"
#include "../tools/utilities.h"
#include "RiskAnalyzer.h"
#include "RiskAnalyzerDOD.h"
#include "Position.h"
#include "PositionDOD.h"
#include <random>

float generateRandomValue(bool pnl) {
    // Obtain a random number from hardware
    static std::random_device rd;
    // Seed the generator
    static std::default_random_engine eng(rd());

    float random;
    // Define the distribution
    if (pnl) {
        std::uniform_real_distribution<> distr(-100, 100);
        random = static_cast<float>(distr(eng));
    } else {
        std::uniform_real_distribution<> distr(0, 10);
        random = static_cast<float>(distr(eng));
    }

    return random;
}


int main() {
    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 10000;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);

    //setup
    auto analyzer = RiskAnalyzer();
    auto analyzerDOD = RiskAnalyzerDOD();


    for (int i = 0; i < 50; i++) {
        auto position = Position(i, "SP500", "13402112");
        auto positionDOD = PositionDOD(i, "SP500", "13402112");
        auto pnl = generateRandomValue(true);
        auto riskExp = generateRandomValue(true);

        //Non-DOD
        position.setPnL(pnl);
        position.setPercExposure(riskExp);
        analyzer.addOpenPosition(position);
        //DOD
        analyzerDOD.addPosition(pnl, riskExp, positionDOD);
    }


    for (int i = 0; i < numRuns; ++i) {
        PAPI_start(EventSet);
        float totPnL = analyzer.totalPnL();
        float totExp = analyzer.totalExposure();
        PAPI_stop(EventSet, counters);
        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }

    for (int i = 0; i < numRuns; ++i) {
        PAPI_start(EventSet);
        float totPnL = analyzerDOD.totalPnL();
        float totExp = analyzerDOD.totalExp();
        PAPI_stop(EventSet, counters);
        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }


    removeOutliers(icm1);
    removeOutliers(icm2);
    removeOutliers(dcm1);
    removeOutliers(dcm2);
    removeOutliers(bmp1);
    removeOutliers(bmp2);
    removeOutliers(cycles1);
    removeOutliers(cycles2);


    auto position = Position(1, "XXXX", "XXXX");
    position.setPnL(55.5); position.setPercExposure(12);

    auto positionDOD = PositionDOD(1, "XXXX", "XXXX");

    std::cout << "Size of position is: " << sizeof(position) << " bytes" << std::endl;
    std::cout << "Size of positionDOD is: " << sizeof(positionDOD) << " bytes" << std::endl;
    std::cout << " " << std::endl;

    std::cout << "Iterations: " << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "Analyzer:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "AnalyzerDOD:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;

    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;
/*
    writeVectorToFile(icm1, "data/icm1.txt");
    writeVectorToFile(dcm1, "data/dcm1.txt");
    writeVectorToFile(bmp1, "data/bmp1.txt");
    writeVectorToFile(cycles1, "data/cycles1.txt");
    writeVectorToFile(icm2, "data/icm2.txt");
    writeVectorToFile(dcm2, "data/dcm2.txt");
    writeVectorToFile(bmp2, "data/bmp2.txt");
    writeVectorToFile(cycles2, "data/cycles2.txt");
*/

    PAPI_shutdown();

    return 0;

}