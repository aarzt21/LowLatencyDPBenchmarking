import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set seaborn style and color palette
sns.set_style('darkgrid')  # Sets the style to darkgrid
sns.set_palette('dark')  # Set the color palette to 'dark'

# Load the data from 'icm1.txt' and 'icm2.txt'
foo_slow_values = np.loadtxt('data/icm1.txt')
foo_fast_values = np.loadtxt('data/icm2.txt')


# Plot the kernel density estimates with shaded area for 'icm1.txt' and 'icm2.txt'
sns.kdeplot(foo_slow_values, label='foo_slow()', color='blue', fill=True)
sns.kdeplot(foo_fast_values, label='foo_fast()', color='violet', fill=True)

# Compute the means
foo_slow_mean = np.mean(foo_slow_values)
foo_fast_mean = np.mean(foo_fast_values)

# Add vertical lines for the means
plt.axvline(foo_slow_mean, color='blue', linestyle='-', label='Mean foo_slow()', linewidth=2)
plt.axvline(foo_fast_mean, color='violet', linestyle='-', label='Mean foo_fast()', linewidth=2)

# Add vertical line at the 5th percentile of each distribution
foo_slow_5th_percentile = np.percentile(foo_slow_values, 5)
plt.axvline(foo_slow_5th_percentile, color='blue', linestyle='--', label='5th Percentile foo_slow()', linewidth=1)

# Set plot labels and title
plt.xlabel('I-Cache Misses')
plt.ylabel('Density')
plt.title('Distribution of foo_slow() and foo_fast() (Outliers Removed)')

# Show the legend
plt.legend()


# Show the plot
plt.tight_layout()
plt.xlim(0, 10000)
plt.savefig('plots/denorm.svg', format="svg")