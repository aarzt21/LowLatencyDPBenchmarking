g++ -O0 -o coldCode coldCodeIsolation.cpp ../tools/utilities.cpp -lpapi
echo "compiled code ... running experiment"
./coldCode