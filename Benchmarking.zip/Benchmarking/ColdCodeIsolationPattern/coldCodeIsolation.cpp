#include <papi.h>
#include <random>
#include <algorithm>
#include "../tools/utilities.h"

using uvec = std::vector<unsigned>;

#define REPEAT8(x) x;x;x;x;x;x;x;x;
#define REPEAT16(x) x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;

#define REPEAT32(x) x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;
#define REPEAT64(x) x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;

uvec generateData(int seed) {
    std::vector<unsigned> data(400000);
    std::default_random_engine generator(seed);
    std::uniform_int_distribution<unsigned> distribution(0, 200000);
    std::generate(data.begin(), data.end(), [&]() { return distribution(generator); });
    return data;
}

int foo_slow(uvec &data) {
    int count = 0;
    for (auto &e: data) {
        count += e; // hot code
        if (e == 0) REPEAT64(count++); // cold code
        count++; // hot code

        if (e == 1000) REPEAT64(count++); // cold code
        count++; // hot code

        if (e == 10000) REPEAT64(count++);// cold code
        count++; // hot code

        if (e == 100000) REPEAT64(count++); // cold code
        count++; // hot code

        if (e == 200000) REPEAT64(count++); // cold code
    }
    return count;
}

void edgeCaseHandler(int errorCode, int &count) {
        REPEAT64(count++);
        return;
}


int foo_fast(uvec &data) {
    int count = 0;
    for (auto &e: data) {
        if (e == 0 || e == 1000 || e == 10000 ||
            e == 100000 || e == 200000)
            edgeCaseHandler(e, count); // cold code separated out

        //hot code
        count += e;
        count ++;
        count ++;
        count ++;
        count ++;
    }
    return count;
}


int main() {
    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 500;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);

    for (int i = 0; i < numRuns; ++i) {
        uvec data = generateData(i);
        PAPI_start(EventSet);
        foo_slow(data);
        PAPI_stop(EventSet, counters);
        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }

    for (int i = 0; i < numRuns; ++i) {
        uvec data = generateData(i);
        PAPI_start(EventSet);
        foo_fast(data);
        PAPI_stop(EventSet, counters);
        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }

    removeOutliers(icm1); removeOutliers(icm2);
    removeOutliers(dcm1); removeOutliers(dcm2);
    removeOutliers(bmp1); removeOutliers(bmp2);
    removeOutliers(cycles1); removeOutliers(cycles2);


    std::cout << "Iterations: " << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "foo_slow():\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "foo_fast():\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;

    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;

    writeVectorToFile(icm1, "data/icm1.txt");
    writeVectorToFile(dcm1, "data/dcm1.txt");
    writeVectorToFile(bmp1, "data/bmp1.txt");
    writeVectorToFile(cycles1, "data/cycles1.txt");
    writeVectorToFile(icm2, "data/icm2.txt");
    writeVectorToFile(dcm2, "data/dcm2.txt");
    writeVectorToFile(bmp2, "data/bmp2.txt");
    writeVectorToFile(cycles2, "data/cycles2.txt");


    PAPI_shutdown();

    return 0;
}
