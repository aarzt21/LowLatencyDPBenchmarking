//
// Created by alex on 27.06.23.
//

#include <iostream>
#include "papi.h"
#include "../tools/utilities.h"

class Base {
protected:
    int counter;
public:
    Base(): counter(0) {};
    virtual void inc(){counter += 1;}
    int getCounter(){return counter;}
};

class Special: public Base {
public:
    void inc() override {counter += 2;}
};


//CRTP -------------------------------------
template <class Derived>
class CRTPTemplate {
protected:
    int counter;
public:
    CRTPTemplate() : counter(0) {}
    void inc(){static_cast<Derived*>(this)->incImpl();}
    int getCounter(){return counter;}
};

class BaseCRTP: public CRTPTemplate<BaseCRTP> {
private:
    friend class CRTPTemplate<BaseCRTP>;
    void incImpl() {counter += 1;}
};

class SpecialCRTP: public CRTPTemplate<SpecialCRTP>{
private:
    friend class CRTPTemplate<SpecialCRTP>;
    void incImpl() {counter += 2;}
};


int main()
{
    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 200;
    int calls = 100000;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);

    //no CRTP ----------------------------------------------------
    auto spec = new Special();
    for (int i = 0; i < numRuns; ++i)
    {
        PAPI_start(EventSet);
        for (int j = 0; j < calls; j++) spec->inc();
        PAPI_stop(EventSet, counters);

        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }
    std::cout << "Counter Dynamic: " << spec->getCounter() << std::endl;


    //CRTP --------------------------------------------------------
    auto specCRTP = new SpecialCRTP();
    for (int i = 0; i < numRuns; ++i)
    {
        PAPI_start(EventSet);
        for (int j = 0; j < calls; j++) specCRTP->inc();
        PAPI_stop(EventSet, counters);

        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }
    std::cout << "Counter Static: " << specCRTP->getCounter() << std::endl;

    removeOutliers(icm1); removeOutliers(icm2);
    removeOutliers(dcm1); removeOutliers(dcm2);
    removeOutliers(bmp1); removeOutliers(bmp2);
    removeOutliers(cycles1); removeOutliers(cycles2);


    std::cout << "Iterations: " << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "No CRTP:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "CRTP:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;


    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;

    writeVectorToFile(icm1, "../data/icm1.txt");
    writeVectorToFile(dcm1, "../data/dcm1.txt");
    writeVectorToFile(bmp1, "../data/bmp1.txt");
    writeVectorToFile(cycles1, "../data/cycles1.txt");
    writeVectorToFile(icm2, "../data/icm2.txt");
    writeVectorToFile(dcm2, "../data/dcm2.txt");
    writeVectorToFile(bmp2, "../data/bmp2.txt");
    writeVectorToFile(cycles2, "../data/cycles2.txt");


    PAPI_shutdown();

    return 0;

}



