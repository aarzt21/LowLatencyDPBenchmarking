//
// Created by alex on 25.06.23.
//
#include "iostream"
#include "papi.h"
#include "../tools/utilities.h"
#include <random>
#define REPEAT32(x) x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;x;


struct Order {
    int orderType;
    float price;
    double stopLoss;
    void send(int amt) volatile {
        amt++;
        amt--;
        amt++;
        amt--;
    };
};

float getStockPrice() {
    static std::default_random_engine generator;
    static std::normal_distribution<float> distribution(100.0, 10.0);
    float price = distribution(generator);
    return price;
}

float getRiskLimitPrice(std::vector<float> riskPrices) {
    static std::default_random_engine generator;
    static std::normal_distribution<float> distribution(2, 1.0);
    float price = distribution(generator);
    float sum = 0;
    for (auto p: riskPrices) sum += p;
    sum += price;
    return sum/16;
}


bool shouldBuy() {
    static std::default_random_engine generator;
    static std::uniform_int_distribution<int> distribution(0, 999);
    int number = distribution(generator);
    return number == 0;
}


std::vector<float> getRiskParameters(float min, float max) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(min, max);

    std::vector<float> vec;
    vec.reserve(15);

    for(int n=0; n<15; ++n) {
        vec.push_back(dis(gen));
    }

    return vec;
}

void logging(){
    int v = 1; int sl = 3;
    REPEAT32(v++)
    REPEAT32(v--)
    REPEAT32(v++)
    REPEAT32(v--)
    REPEAT32(v++)
    REPEAT32(v--)
    REPEAT32(v++)
    REPEAT32(v--)
    REPEAT32(sl++)
    REPEAT32(sl--)
    REPEAT32(sl++)
    REPEAT32(sl--)
    REPEAT32(sl++)
    REPEAT32(sl--)
    REPEAT32(sl++)
    REPEAT32(sl--)
}

int main()
{
    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 1000;
    int w = 20000;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);

    //No Chache Priming --------------------------------------------------------
    for (int i = 0; i < numRuns; ++i)
    {
        auto riskParams = getRiskParameters(0, 4);

        PAPI_start(EventSet);
        for (int j = 0; j < w; ++j)
        {
            if (shouldBuy()) {
                auto p = getStockPrice();
                auto stopLoss = getRiskLimitPrice(riskParams);
                auto order = Order();
                order.price = p;
                order.stopLoss = stopLoss;
                order.orderType = 1;
                order.send(100);
                logging();
            }
        }
        PAPI_stop(EventSet, counters);

        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }


    //Cache Priming --------------------------------------------------------
    for (int i = 0; i < numRuns; ++i)
    {

        auto riskParams = getRiskParameters(0, 4);

        PAPI_start(EventSet);
        for (int j = 0; j < w; ++j) {
            if (j % 200 == 0) {
                auto dummyPrice = getStockPrice();
                auto dummyStopLoss = getRiskLimitPrice(riskParams);
                auto dummyOrder = Order();
                dummyOrder.price = dummyPrice;
                dummyOrder.stopLoss = dummyStopLoss;
                dummyOrder.orderType = 1;
                dummyOrder.send(0);

            }

            if (shouldBuy()) {
                auto p = getStockPrice();
                auto stopLoss = getRiskLimitPrice(riskParams);
                auto order = Order();
                order.price = p;
                order.stopLoss = stopLoss;
                order.orderType = 1;
                order.send(100);
                logging();
            }
        }
        PAPI_stop(EventSet, counters);

        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }

    removeOutliers(icm1); removeOutliers(icm2);
    removeOutliers(dcm1); removeOutliers(dcm2);
    removeOutliers(bmp1); removeOutliers(bmp2);
    removeOutliers(cycles1); removeOutliers(cycles2);


    std::cout << "Iterations: " << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "Normal Variant:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "Cache Priming Variant:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;


    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;

    writeVectorToFile(icm1, "../data/icm1.txt");
    writeVectorToFile(dcm1, "../data/dcm1.txt");
    writeVectorToFile(bmp1, "../data/bmp1.txt");
    writeVectorToFile(cycles1, "../data/cycles1.txt");
    writeVectorToFile(icm2, "../data/icm2.txt");
    writeVectorToFile(dcm2, "../data/dcm2.txt");
    writeVectorToFile(bmp2, "../data/bmp2.txt");
    writeVectorToFile(cycles2, "../data/cycles2.txt");


    PAPI_shutdown();

    return 0;

}