import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# Set seaborn style and color palette
sns.set_style('darkgrid')
sns.set_palette('dark')

# Load the data
nonCachePrimingValues = np.loadtxt('data/icm1.txt')
cachePrimingValues = np.loadtxt('data/icm2.txt')
nonCPValues = np.loadtxt('data/icm1.txt')
CPValue = np.loadtxt('data/icm2.txt')

# Compute the means
nonCP_mean = np.mean(nonCachePrimingValues)
CP_mean = np.mean(cachePrimingValues)
nonCPmean = np.mean(nonCPValues)
CPmean = np.mean(CPValue)

# Compute the observed statistic
observed_statistic = np.abs(nonCPmean - CPmean)

# Initialize the plot
fig, ax = plt.subplots()

# Plot the kernel density estimates with shaded area
sns.kdeplot(nonCachePrimingValues, label='No Cache Priming', color='blue', fill=True, ax=ax)
sns.kdeplot(cachePrimingValues, label='Cache Priming', color='violet', fill=True, ax=ax)

# Add vertical lines for the means
ax.axvline(nonCP_mean, color='blue', linestyle='-', label='Mean No CP', linewidth=2)
ax.axvline(CP_mean, color='violet', linestyle='-', label='Mean CP', linewidth=2)

# Set labels and title for the main plot
ax.set_xlabel('I-Cache Misses')
ax.set_ylabel('Density')
ax.set_title('Distribution of Non-CP and CP Implementation (Outliers Removed)')
ax.legend()
ax.set_xlim(100, 600)

# Initialize the inset axes (the miniplot)
ax_inset = inset_axes(ax, width=2.5, height=2, loc="upper right", borderpad=1.5)

# Perform permutation test
n_permutations = 10000
permuted_statistics = np.zeros(n_permutations)
for i in range(n_permutations):
    combined = np.concatenate([nonCPValues, CPValue])
    np.random.shuffle(combined)
    permutednonCP = combined[:len(nonCPValues)]
    permutedCP = combined[len(nonCPValues):]
    permuted_statistics[i] = np.abs(np.mean(permutednonCP) - np.mean(permutedCP))

# Compute p-value
p_value = np.mean(permuted_statistics > observed_statistic)
percentile_95 = np.percentile(permuted_statistics, 95)

# Plot the distribution of permuted statistics on the inset axes
sns.kdeplot(permuted_statistics, color='darkorange', label='Perm. Dist.', fill=True, ax=ax_inset)
ax_inset.axvline(observed_statistic, color='black', linestyle='--', label=f'Obs. Stat.', linewidth=1)
ax_inset.axvline(percentile_95, color='orange', linestyle='--', label=f'95th P.', linewidth=1)

# Set labels and title for the inset plot
ax_inset.set_title('Perm. Test (Diff. of Means)', fontsize=10)
ax_inset.set_xlabel('Diff. of Means', fontsize=8)
ax_inset.set_ylabel('Density', fontsize=8)
ax_inset.legend(fontsize=6)

# Add legends for the main plot and the inset plot
ax.legend(fontsize=8, loc='lower right')

plt.tight_layout()
plt.savefig('plots/combinedPlot3.svg', format="svg")
