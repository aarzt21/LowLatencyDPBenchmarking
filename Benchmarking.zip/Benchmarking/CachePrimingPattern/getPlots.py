import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set seaborn style and color palette
sns.set_style('darkgrid')  # Sets the style to darkgrid
sns.set_palette('dark')  # Set the color palette to 'dark'

# Load the data from 'icm1.txt' and 'icm2.txt'
nonCachePrimingValues = np.loadtxt('data/dcm1.txt')
cachePrimingValues = np.loadtxt('data/dcm2.txt')


# Plot the kernel density estimates with shaded area for 'icm1.txt' and 'icm2.txt'
sns.kdeplot(nonCachePrimingValues, label='No Cache Priming', color='blue', fill=True)
sns.kdeplot(cachePrimingValues, label='Cache Priming', color='violet', fill=True)

# Compute the means
nonCP_mean = np.mean(nonCachePrimingValues)
CP_mean = np.mean(cachePrimingValues)

# Add vertical lines for the means
plt.axvline(nonCP_mean, color='blue', linestyle='-', label='Mean No CP', linewidth=2)
plt.axvline(CP_mean, color='violet', linestyle='-', label='Mean CP', linewidth=2)

# Add vertical line at the 5th percentile of each distribution
foo_slow_5th_percentile = np.percentile(nonCachePrimingValues, 5)
plt.axvline(foo_slow_5th_percentile, color='blue', linestyle='--', label='5th Percentile No CP', linewidth=1)

# Set plot labels and title
plt.xlabel('D-Cache Misses')
plt.ylabel('Density')
plt.title('Distribution of Non-CP and CP Implementation (Outliers Removed)')

# Show the legend
plt.legend()

plt.xlim(0, 20)
# Show the plot
plt.tight_layout()
plt.savefig('plots/cachePrimingDCM.svg', format="svg")