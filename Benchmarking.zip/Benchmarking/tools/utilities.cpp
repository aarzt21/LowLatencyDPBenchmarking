//
// Created by alex on 21.06.23.
//

#include "utilities.h"

double calculateAvg(const std::vector<long long> &vec) {
    double sum = std::accumulate(vec.begin(), vec.end(), 0.0);
    return sum / vec.size();
}


double calculateStdDev(const std::vector<long long> &vec) {
    double mean = calculateAvg(vec);
    double sqSum = 0;
    for (int i = 0; i < vec.size(); ++i) {
        double diff = mean - vec[i];
        sqSum += (diff * diff);
    }
    return sqrt(sqSum / (vec.size() - 1));
}


void writeVectorToFile(const std::vector<long long> &vec, const std::string &filename) {
    std::ofstream file(filename);
    if (file.is_open()) {
        for (const auto &value: vec) {
            file << value << "\n";
        }
        file.close();
        std::cout << "Vectors written to " << filename << std::endl;
    } else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
}

#include <vector>
#include <algorithm>

void removeOutliers(std::vector<long long>& vec) {
    // Sort the vector
    std::sort(vec.begin(), vec.end());

    // Calculate the 99th percentile
    long long percentile_99_index = static_cast<long long>(vec.size() * 0.99);
    long long percentile_99_value = vec[percentile_99_index];

    // Erase elements larger than the 99th percentile
    vec.erase(std::remove_if(vec.begin(), vec.end(),
                             [percentile_99_value](long long val) { return val > percentile_99_value; }), vec.end());
}
