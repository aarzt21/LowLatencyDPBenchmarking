//
// Created by alex on 21.06.23.
//

#ifndef CPPDESIGNPATTERNSHFT_UTILITIES_H
#define CPPDESIGNPATTERNSHFT_UTILITIES_H

#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <numeric>

double calculateAvg(const std::vector<long long> &vec);


double calculateStdDev(const std::vector<long long> &vec);


void writeVectorToFile(const std::vector<long long> &vec, const std::string &filename);

void removeOutliers(std::vector<long long>& vec);


#endif //CPPDESIGNPATTERNSHFT_UTILITIES_H
