
//
// Created by alex on 23.06.23.
//

#include <papi.h>
#include "Instrument.h"
#include "InstrumentDenorm.h"
#include "TradingEngine.h"
#include "../tools/utilities.h"
#include <iostream>

#include <random>




int generate_random_number(int lower, int upper) {
    static std::default_random_engine e;
    static std::uniform_int_distribution<int> dist(lower, upper);
    int n = dist(e);
    std::cout << n << std::endl;
    return n;
}



int main(){


    PAPI_library_init(PAPI_VER_CURRENT);
    int EventSet = PAPI_NULL;
    PAPI_create_eventset(&EventSet);
    PAPI_add_event(EventSet, PAPI_L1_ICM);        // L1 instruction cache misses
    PAPI_add_event(EventSet, PAPI_L1_DCM);        // L1 data cache misses
    PAPI_add_event(EventSet, PAPI_BR_MSP);        // Branch mispredictions
    PAPI_add_event(EventSet, PAPI_TOT_CYC);       // Total cycles

    long_long counters[4];
    int numRuns = 500;

    std::vector<long long> icm1(numRuns), dcm1(numRuns), bmp1(numRuns), cycles1(numRuns);
    std::vector<long long> icm2(numRuns), dcm2(numRuns), bmp2(numRuns), cycles2(numRuns);

    //setup
    auto engine = TradingEngine();
    for (int i = 1; i <= 10; i++) {
        engine.setMarketMap(i, 2.7);
        engine.setOrderMap(i, 1);
    }


    auto engineDenorm = TradingEngine();

    for (int i = 0; i < 200 ; i++){
        auto instrument = Instrument(i, generate_random_number(1, 10));
        auto instrumentDenorm = InstrumentDenorm(i, generate_random_number(1, 10), 2.7, 1);
        engine.addAsset(instrument);
        engineDenorm.addAssetDenorm(instrumentDenorm);
    }

    //Benchmarking -----------------------

    //Denormalised Version
    for (int i = 0; i < numRuns; ++i) {
        PAPI_start(EventSet);
        engineDenorm.checkForTradingSignalDenorm();
        PAPI_stop(EventSet, counters);
        icm2[i] = counters[0];
        dcm2[i] = counters[1];
        bmp2[i] = counters[2];
        cycles2[i] = counters[3];
        PAPI_reset(EventSet);
    }


    //Normalised Version
    for (int i = 0; i < numRuns; ++i) {
        PAPI_start(EventSet);
        engine.checkForTradingSignal();
        PAPI_stop(EventSet, counters);
        icm1[i] = counters[0];
        dcm1[i] = counters[1];
        bmp1[i] = counters[2];
        cycles1[i] = counters[3];
        PAPI_reset(EventSet);
    }


    removeOutliers(icm1);
    removeOutliers(icm2);
    removeOutliers(dcm1);
    removeOutliers(dcm2);
    removeOutliers(bmp1);
    removeOutliers(bmp2);
    removeOutliers(cycles1);
    removeOutliers(cycles2);


    std::cout << "Iterations: " << numRuns << std::endl;
    std::cout << "------------------------------------" << std::endl;
    std::cout << "Normalised Implementation:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm1) << " (StdDev: " << calculateStdDev(icm1)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm1) << " (StdDev: " << calculateStdDev(dcm1) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp1) << " (StdDev: " << calculateStdDev(bmp1) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles1) << " (StdDev: " << calculateStdDev(cycles1) << ")"
              << std::endl;

    std::cout << "------------------------------------" << std::endl;

    std::cout << "Denormalised Implementation:\n";
    std::cout << "Average instruction cache misses: " << calculateAvg(icm2) << " (StdDev: " << calculateStdDev(icm2)
              << ")" << std::endl;
    std::cout << "Average data cache misses: " << calculateAvg(dcm2) << " (StdDev: " << calculateStdDev(dcm2) << ")"
              << std::endl;
    std::cout << "Average branch mispredictions: " << calculateAvg(bmp2) << " (StdDev: " << calculateStdDev(bmp2) << ")"
              << std::endl;
    std::cout << "Average total cycles: " << calculateAvg(cycles2) << " (StdDev: " << calculateStdDev(cycles2) << ")"
              << std::endl;


    std::cout << "------------------ Writing Results to Data Folder -------------------" << std::endl;
    writeVectorToFile(icm1, "../data/icm1.txt");
    writeVectorToFile(dcm1, "../data/dcm1.txt");
    writeVectorToFile(bmp1, "../data/bmp1.txt");
    writeVectorToFile(cycles1, "../data/cycles1.txt");
    writeVectorToFile(icm2, "../data/icm2.txt");
    writeVectorToFile(dcm2, "../data/dcm2.txt");
    writeVectorToFile(bmp2, "../data/bmp2.txt");
    writeVectorToFile(cycles2, "../data/cycles2.txt");

    PAPI_shutdown();

    return 0;



}