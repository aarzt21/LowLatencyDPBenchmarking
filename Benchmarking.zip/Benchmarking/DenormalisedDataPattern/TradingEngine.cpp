//
// Created by alex on 23.06.23.
//

#include <iostream>
#include "TradingEngine.h"

TradingEngine::TradingEngine() : assets(), assetsDenorm(), marketMap(), OrderType() {}

void TradingEngine::checkForTradingSignal() {
    int orders = 0;
    for (int i = 0 ; i < 1000; i++){
        for (auto asset: assets){
            if (asset.checkSignal()){
                orders++;
                createOrder(asset);
            }
        }
    }
    std::cout << "created " << orders << " normal orders" << std::endl;
}

void TradingEngine::checkForTradingSignalDenorm() {
    int orders = 0;
    for (int i = 0 ; i < 1000; i++){
        for (auto asset: assetsDenorm){
            if (asset.checkSignal()){
                orders++;
                createOrderDenorm(asset);
            }
        }
    }
    std::cout << "created " << orders << " denormalized orders" << std::endl;
}

void TradingEngine::createOrder(Instrument asset) {

    // two lookups here
    auto market = marketMap[asset.marketID];
    auto mult = market.multiplier;
    auto orderType = OrderType[asset.marketID];
    //...
}

void TradingEngine::createOrderDenorm(InstrumentDenorm asset) {
    //no lookups
    auto mult = asset.multiplier;
    auto oType = asset.orderType;
    //...
}

void TradingEngine::setMarketMap(int marketID, float mult) {
    auto market = Market();
    market.ID = marketID;
    market.multiplier = mult;
    marketMap[marketID] = market;
}

void TradingEngine::addAsset(Instrument instrument) {
    assets.push_back(instrument);
}

void TradingEngine::addAssetDenorm(InstrumentDenorm instrument) {
    assetsDenorm.push_back(instrument);
}

void TradingEngine::setOrderMap(int marketID, int type) {
    OrderType[marketID] = type;
}
