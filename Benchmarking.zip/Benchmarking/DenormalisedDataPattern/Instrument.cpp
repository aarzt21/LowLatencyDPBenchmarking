//
// Created by alex on 23.06.23.
//

#include <iostream>
#include "Instrument.h"

Instrument::Instrument(int id, int marketId) : ID(id), marketID(marketId) {}

std::default_random_engine Instrument::e{};
std::uniform_int_distribution<int> Instrument::dist{1, 1000};

bool Instrument::checkSignal() {
    int random_number = dist(e);
    //std::cout << "random number " << random_number << std::endl;
    return random_number == 1;
}



