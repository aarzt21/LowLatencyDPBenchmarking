//
// Created by alex on 23.06.23.
//

#ifndef DENORMALISEDDATAPATTERN_INSTRUMENT_H
#define DENORMALISEDDATAPATTERN_INSTRUMENT_H


#include <string>
#include <random>

struct Instrument {
    Instrument(int id, int marketId);

    int ID;
    int marketID;
    static std::default_random_engine e;
    static std::uniform_int_distribution<int> dist;
    Instrument(int id);

    bool checkSignal();
};


#endif //DENORMALISEDDATAPATTERN_INSTRUMENT_H
