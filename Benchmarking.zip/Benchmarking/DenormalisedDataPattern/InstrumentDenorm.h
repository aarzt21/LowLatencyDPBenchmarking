//
// Created by alex on 23.06.23.
//

#ifndef DENORMALISEDDATAPATTERN_INSTRUMENTDENORM_H
#define DENORMALISEDDATAPATTERN_INSTRUMENTDENORM_H


#include <random>

struct InstrumentDenorm {
    InstrumentDenorm(int id, int marketId, float multiplier, int ordertype);

    static std::default_random_engine e;
    static std::uniform_int_distribution<int> dist;

    int ID;
    int MarketID;
    float multiplier;
    int orderType;

    bool checkSignal();
};


#endif //DENORMALISEDDATAPATTERN_INSTRUMENTDENORM_H
