//
// Created by alex on 23.06.23.
//

#ifndef DODPATTERN_TRADINGENGINE_H
#define DODPATTERN_TRADINGENGINE_H

#include <vector>
#include <map>
#include "Instrument.h"
#include "InstrumentDenorm.h"
#include "Market.h"

class TradingEngine {
    std::vector<Instrument> assets;
    std::vector<InstrumentDenorm> assetsDenorm;
    std::map<int, Market> marketMap;
    std::map<int, int> OrderType;

public:
    TradingEngine();

    void addAsset(Instrument instrument);

    void addAssetDenorm(InstrumentDenorm instrument);

    void setMarketMap(int marketID, float mult);

    void setOrderMap(int marketID, int type);

    void checkForTradingSignal();

    void checkForTradingSignalDenorm();

    void createOrder(Instrument asset);

    void createOrderDenorm(InstrumentDenorm asset);
};


#endif //DODPATTERN_TRADINGENGINE_H
