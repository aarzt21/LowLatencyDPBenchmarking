//
// Created by alex on 23.06.23.
//

#ifndef DENORMALISEDDATAPATTERN_MARKET_H
#define DENORMALISEDDATAPATTERN_MARKET_H


struct Market {
    int ID;
    char shortName[4];
    int multiplier;
};


#endif //DENORMALISEDDATAPATTERN_MARKET_H
