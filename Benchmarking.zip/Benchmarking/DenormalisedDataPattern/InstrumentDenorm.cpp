//
// Created by alex on 23.06.23.
//

#include <iostream>
#include "InstrumentDenorm.h"

InstrumentDenorm::InstrumentDenorm(int id, int marketId, float multiplier, int ordertype) : ID(id), MarketID(marketId),
                                                                                            multiplier(multiplier) {}

std::default_random_engine InstrumentDenorm::e{};
std::uniform_int_distribution<int> InstrumentDenorm::dist{1, 1000};

bool InstrumentDenorm::checkSignal() {
    int random_number = dist(e);
    //std::cout << "random number " << random_number << std::endl;
    return random_number == 1;
}



