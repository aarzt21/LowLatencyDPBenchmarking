//
// Created by alex on 28.06.23.
//

#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
using namespace std;



class Base {
protected:
    int counter;
public:
    Base(): counter(0){};
    virtual void inc(){counter += 0;}
    int getValue(){return counter;}
};

class Child1: public Base {
public:
    void inc() override{counter += 1;}
};


class Child2: public Base {
public:
    void inc() override{counter += 2;}
};


class Child3: public Base {
public:
    void inc() override{counter += 3;}
};



template<typename Derived>
class Template{
protected:
    int counter;
public:
    Template(): counter(0) {};
    void inc(){static_cast<Derived*>(this)->inc();}
    int getValue(){return counter;}
};

class Child1CRTP: Template<Child1CRTP> {
    void inc(){counter += 1;}
};


class Child2CRTP: Template<Child2CRTP> {
    void inc(){counter += 2;}
};


class Child3CRTP: Template<Child3CRTP> {
    void inc(){counter += 3;}
};


int main()
{
    vector<Base*> vec;
    for (int i = 0; i < 1000000; i++){
        Base* c1 = new Child1();
        Base* c2 = new Child2();
        Base* c3 = new Child3();
        vec.push_back(c1);
        vec.push_back(c2);
        vec.push_back(c3);
    }

#ifndef Shuffle
    int64_t res = 0;
    for (auto c: vec) {c->inc(); res += c->getValue();}
    std::cout << "Not Shuffled Result: " << res << std::endl;

#else
    random_device rd;
    mt19937 g(rd());
    shuffle(vec.begin(), vec.end(), g);

    int64_t res2 = 0;
    for (auto c: vec) {c->inc(); res2 += c->getValue();}
    std::cout << "Not Shuffled Result: " << res2 << std::endl;

#endif
    return 0;
};


















