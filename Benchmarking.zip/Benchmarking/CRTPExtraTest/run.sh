
#!/bin/bash

optim=O0;
g++ -"$optim" -o notShuffled main.cpp
g++ -"$optim" -DShuffle  -o shuffled main.cpp

echo "Finished Compiling... running now"

perf stat ./notShuffled
perf stat ./shuffled

